from machine import Pin, time_pulse_us
import time

SOUND_SPEED = 340  # Speed of sound in air
TRIG_PULSE_DURATION_US = 10

trig_pin = Pin(5, Pin.OUT)
echo_pin = Pin(18, Pin.IN)
led = Pin(2, Pin.OUT)

while True:
    # Prepare the signal
    trig_pin.value(0)
    time.sleep_us(5)
    # Create a 10 µs pulse
    trig_pin.value(1)
    time.sleep_us(TRIG_PULSE_DURATION_US)
    trig_pin.value(0)

    ultrason_duration = time_pulse_us(echo_pin, 1, 30000)  # Returns the wave propagation time (in µs)
    distance_cm = SOUND_SPEED * ultrason_duration / 20000 #20000

    distance_cm_rounded = round(distance_cm, 2)

    if distance_cm_rounded <= 100.00:
      for i in range(5):
        led.on()
        time.sleep(0.2)
        led.off()
        time.sleep(0.2)
    elif 100.00 < distance_cm_rounded <= 200.00:
      for i in range(5):  
        led.on()
        time.sleep(0.3)
        led.off()
        time.sleep(0.3)
    elif 200.00 < distance_cm_rounded <= 300.00:
      for i in range(5):  
        led.on()
        time.sleep(1)
        led.off()
        time.sleep(1)
    else:
      led.off 

    print(f"Distance : {distance_cm_rounded} cm")
    time.sleep_ms(1)
