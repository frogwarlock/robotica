import machine
import time

# A BAIXO DE 99 ELE LIGA PQ TA ESCUROOOO

# Configuração do pino do sensor de luminosidade (LDR)
ldr_pin = machine.Pin(4, machine.Pin.IN)

# Configuração do pino do LED
led_pin = machine.Pin(2, machine.Pin.OUT)

# Função para ler o valor do sensor de luminosidade
def read_ldr():
    return ldr_pin.value()

# Loop principal
while True:
    # Lê o valor do sensor de luminosidade
    ldr_value = read_ldr()
    print(ldr_value)

    # Se estiver mais escuro (o valor do sensor é alto - 1), acende o LED
    if ldr_value == 1:
        led_pin.on()
    else:
        led_pin.off()

    # Aguarda um curto período de tempo antes de verificar novamente
    time.sleep(0.1)
